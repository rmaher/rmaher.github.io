$(function() {
	$("#wizards a").lightBox();
});
